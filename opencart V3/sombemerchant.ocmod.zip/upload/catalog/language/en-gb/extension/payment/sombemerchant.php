<?php

$_['text_title']      = 'SombeMerchant';
$_['button_confirm']  = 'Pay with SombeMerchant';
