<?php

$_['text_title']      = 'Sombe Merchant';
$_['button_confirm']  = 'Pay with Sombe Merchant';
